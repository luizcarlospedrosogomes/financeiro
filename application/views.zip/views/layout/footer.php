<div style="clear:both;"></div>
<div style="height:50px; width:100%; border:1px solid #000;"> Your Website Footer Section</div>