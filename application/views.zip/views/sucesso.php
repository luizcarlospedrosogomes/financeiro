<!DOCTYPE html>
<html>
    <head>
        <title>Financiro</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/css/.css');?>">
    </head>
	<body>			
			<h3><?php echo $msg;?></h3>
			<?php redirect('usuario', 'refresh',3);?>
	
   </body>
</html>