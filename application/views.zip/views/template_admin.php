<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Financeiro | Pessoal</title>
</head>
<body>

<div id="container">
	<h1>Bem vindo ao seu Gerenciador de Finanças -> Administrador</h1>
</div>
<div id="incluir_usuario"></div>
<div id="listar_usuario"></div>
</body>
</html>